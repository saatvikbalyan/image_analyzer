import axios from "axios";

const imageAnalyzer = async(url) => {
  try {
    const res = await axios.post(
      "https://classifier97.cognitiveservices.azure.com/vision/v3.2/analyze?visualFeatures=Categories,Description,Objects",
      {url},
      {
        headers: {
          "Ocp-Apim-Subscription-Key": process.env.REACT_APP_MS_API_KEY,
          "Content-Type": "application/json",
        },
      }
    );
    console.log(res.data);
    return res.data;
  } catch (e) {
    console.error(e);
    return null;
  }
};

export { imageAnalyzer };
