import { useState } from "react";
import "./App.css";
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
} from "firebase/storage";
import Loader from "./components/loader";
import Button from "./components/button";
import { imageAnalyzer } from "./apis/imageAlalyzer";
require("./config/firebase");

function App() {
  const [loading, setLoading] = useState(false);
  const [imageAsUrl, setImageAsUrl] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [imageData, setImageData] = useState(null);
  const [error, setError] = useState("");

  const handleImage = (e) => {
    setError("");
    if (!loading) {
      setLoading(true);
      const image = e.target.files[0];

      if (image === "" || image === undefined) {
        setLoading(false);
        alert(`not an image, the file is a  ${typeof image}`);
        return;
      }
      firebaseUpload(image);
    }
  };

  const firebaseUpload = (file) => {
    const storage = getStorage();
    const storageRef = ref(
      storage,
      `images/${file.name || Math.random().toString(16).substring(2, 14)}`
    );
    const uploadTask = uploadBytesResumable(storageRef, file);
    uploadTask.on(
      "state_changed",
      (snapshot) => {},
      (error) => {
        // Handle unsuccessful uploads
        console.log(error.message);
        setError(error.message);
        setLoading(false);
      },
      () => {
        // Handle successful uploads on complete
        // For instance, get the download URL: https://firebasestorage.googleapis.com/...
        getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          setImageAsUrl(downloadURL);
          setLoading(false);
          setAnalyzing(true);
          analyze(downloadURL);
        });
      }
    );
  };

  const analyze = async (url) => {
    const analyzation = await imageAnalyzer(url);
    if (analyzation) {
      setImageData(analyzation);
    } else {
      setError("No data found for this image !");
    }
    setAnalyzing(false);
  };

  return (
    <div className="App">
      <div style={{ position: "absolute", width: "100%", paddingBlock: 20 }}>
        <text
          style={{
            color: "white",
            fontSize: 28,
            textAlign: "center",
            fontWeight: "bold",
          }}
        >
          Image Analyzer
        </text>
      </div>
      <div className="App-header">
        <input
          id="file"
          style={{ display: "none" }}
          name={"image"}
          type="file"
          onChange={(e) => handleImage(e)}
          accept={"image/jpg , image/png, image/jpeg"}
        />
        {!loading ? (
          <label htmlFor="file">
            <Button />
          </label>
        ) : (
          <Loader />
        )}
        <text style={{ fontSize: 15, color: "red" }}>{error}</text>
        {imageAsUrl !== null ? (
          <div>
            <img
              src={imageAsUrl}
              height="400px"
              width="auto"
              style={{ maxWidth: "80%" }}
              alt="uploaded_image"
            />
          </div>
        ) : null}
        {analyzing ? (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              marginTop: 40,
            }}
          >
            <Loader />
            <text style={{ color: "white", fontSize: 14, marginLeft: 5 }}>
              Analyzing Image
            </text>
          </div>
        ) : null}
        {imageData !== null ? (
          <div style={{display:'flex',flexDirection:'column',width:'100%',alignItems:'center'}}>
            <text style={{fontSize: 20}}>Image Data</text>
            <div className="databox">
              <text>
                Categories:{" "}
                {imageData?.categories?.length
                  ? imageData.categories.map((v, index) => (
                      `${v.name}(${v.score}), `
                    ))
                  : null}
              </text>
              <text>
                Description: {imageData?.description?.captions?.text || null}
              </text>
              <text>
                Tags :{" "}
                {imageData?.description?.tags?.length
                  ? imageData.description.tags.map((v, index) => (
                    `${v}, `
                    ))
                  : null}
              </text>
              <text>
                Objects:{" "}
                {imageData?.objects?.length
                  ? imageData.objects.map((v, index) => (
                    `${v.object}, `
                    ))
                  : null}
              </text>
            </div>
            <text style={{fontSize:20}}>Raw Data</text>
            <div className="databox">
              <text>{JSON.stringify(imageData)}</text>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default App;
