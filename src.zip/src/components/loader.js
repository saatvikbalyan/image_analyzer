import '../styles/loader.css';

const loader = () => {
    return <div className='loader'></div>
}
export default loader;