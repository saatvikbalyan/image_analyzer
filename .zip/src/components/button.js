const Button = () => {
  return (
    <div
      style={{
        display: "flex",
        backgroundColor: "blueviolet",
        width: "fit-content",
        padding: "10px",
        borderRadius: "5px",
        marginBottom: "20px",
        color: "white",
      }}
    >
      <text style={{ marginLeft: "3px", fontSize:16 }}>Upload Image</text>
    </div>
  );
};
export default Button;
